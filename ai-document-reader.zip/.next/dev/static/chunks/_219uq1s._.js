(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0cbk-n2._.css","static/chunks/node_modules_next_dist_20wefz_._.js","static/chunks/_1avurmf._.js"],
    source: "entry"
});
